﻿angular.module('app').controller('LandingController', function ($scope) {

});