﻿angular.module('app').controller('HomeController', function ($scope) {

});